﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace echarts.demo.Controllers
{
    public class PGController : Controller
    {



        // GET: Paging
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetPgView(int pgind, int pgsize)
        {
            if (pgind == 0)
            {
                pgind = 1;
            }

            var retlist = GetDataList(pgind, pgsize);
            ViewData["totalrows"] = retlist.Item1;
            return View(retlist.Item2);
        }


        Tuple<int,List<TEnt>> GetDataList(int pgind, int pgsize)
        {
            var offset = (pgind - 1)*pgsize;
            return new Tuple<int, List<TEnt>>(DataMocker.DSource.Count,DataMocker.DSource.Skip(offset).Take(pgsize).ToList());

        } 
    }
}