﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace echarts.demo.Controllers
{
    public class PGController : Controller
    {



        // GET: Paging
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetPgView(string content, int pageIndex, int pageSize)
        {
            if (pageIndex == 0)
            {
               pageIndex = 1;
            }

            var retlist = GetDataList(pageIndex,pageSize);
            ViewData["totalrows"] = retlist.Item1;

  	ViewData["TotalRow"] = retlist.Item1;
            ViewData["content"] = content;
          ViewData["PageIndex"]=pageIndex;
            ViewData["PageSize"]=pageSize;
            return View(retlist.Item2);
        }


        Tuple<int,List<TEnt>> GetDataList(int pgind, int pgsize)
        {
            var offset = (pgind - 1)*pgsize;
            return new Tuple<int, List<TEnt>>(DataMocker.DSource.Count,DataMocker.DSource.Skip(offset).Take(pgsize).ToList());

        } 
    }
}